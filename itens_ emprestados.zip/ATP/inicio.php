<?php
		include "Cabecalho.php";		
?>
	
		<header>
			<h2>Login</h2>
		</header>
		<section>	
			<?php
				
				include "menu.php";
				
			?>
			
		 <article>
				Seja Bem-vindo!<br/><br/><br/><br/>	
				
				<br/><a href="logout.php">Sair</a>
			</article>
		</section>

<?php
		include "rodape.php";
?>
