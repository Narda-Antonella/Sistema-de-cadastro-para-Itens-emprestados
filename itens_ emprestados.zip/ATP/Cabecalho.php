
<!DOCTYPE html>
<html>
	<head>
		<title>Coisas Emprestadas </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href ="tipo.css" rel="stylesheet"> 
	</head>
	<body>