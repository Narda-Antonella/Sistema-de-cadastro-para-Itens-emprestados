 <nav>
				<ul id ="menu">
					<li><a href="inicio.php">Inicio</a></li>
					<li><a href="listausuario.php">Cadastro de Usuario</a></li>
					<li><a href="listaitens.php">Itens Disponiveis</a></li>
					<li><a href="listaemprestimo.php">Emprestimo</a></li>
					<li><a href="listaitenspend.php">Itens Pendentes</a></li>
					
				</ul>
		</nav>
